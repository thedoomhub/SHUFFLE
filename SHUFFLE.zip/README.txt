Playlist Shuffler 
(Originally meant for personal use)

=============================
HOW TO RUN:
=============================
Insert MP3 files into the same folder as the EXE file. If the file name is too long, the text may be too long from the screen. While efforts
have been made to reduce this issue, it can still sometimes happen.

============================
Controls
=============================
A and D to move back and forward by 5 seconds.
Left and right arrow keys to skip ahead or play the previous song.
Space to pause.

=============================
Is it safe?
=============================
Inside the folder is the script the EXE uses. It is generally safe to run the EXE.

=============================
Additional Notes
=============================
The script only recognises MP3 files. Any other media files will be ignored.